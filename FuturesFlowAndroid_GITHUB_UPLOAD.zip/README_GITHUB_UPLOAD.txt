FuturesFlow Android — GitHub upload package

IMPORTANT: This package intentionally has NO hidden .github folder. macOS Finder can hide it, and GitHub web upload may omit it. Create the workflow separately using GitHub's Add file > Create new file.

A) Upload project files
1. Extract this ZIP.
2. Open the extracted folder. Select app/, README.md, build.gradle.kts, gradle.properties, settings.gradle.kts, .gitignore if present, README_GITHUB_UPLOAD.txt, and GITHUB_WORKFLOW_TO_CREATE.txt.
3. Upload these items directly to the ROOT of your GitHub repository. Do not upload the containing folder.
4. Commit. The repository root must show app/, settings.gradle.kts, build.gradle.kts and gradle.properties.

B) Create the GitHub Actions workflow (one-time)
1. In the repository root click Add file > Create new file.
2. In the filename field enter exactly: .github/workflows/futuresflow-build.yml
   GitHub will create the hidden folders automatically.
3. Open GITHUB_WORKFLOW_TO_CREATE.txt from this ZIP in a text editor, copy ALL its contents, and paste into GitHub's editor.
4. Click Commit changes.

C) Run the build
1. Open Actions.
2. Select FuturesFlow Android APK (corrected).
3. Click Run workflow.
4. If it succeeds, open the run and download the artifact named futuresflow-debug-apk.

Do not keep an old workflow that invokes `gradle assembleDebug` at the repository root. Disable/delete old conflicting workflows.

Validation note: This package structure and workflow are prepared for GitHub Actions. An actual Android build has NOT been executed in this environment. A successful Actions run is the proof of compilation.

Functional note: The current signal engine is intentionally fail-closed and does not emit trading alerts until signal/target methodology is validated. Initial market feed scope is BTCUSDT only. This is not yet a completed production trading signal app.
